package com.simplemobiletools.clock.models

data class StateWrapper(val state: TimerState)
