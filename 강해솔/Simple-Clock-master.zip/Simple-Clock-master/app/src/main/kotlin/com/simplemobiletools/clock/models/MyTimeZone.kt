package com.simplemobiletools.clock.models

data class MyTimeZone(val id: Int, var title: String, val zoneName: String)
