package com.simplemobiletools.clock.interfaces

interface ToggleAlarmInterface {
    fun alarmToggled(id: Int, isEnabled: Boolean)
}
